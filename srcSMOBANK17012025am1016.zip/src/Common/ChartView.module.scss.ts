/* tslint:disable */
require("./ChartView.module.css");
const styles = {
  ChartViewcontainer: 'ChartViewcontainer_d7beb3fd',
  ContorlSection: 'ContorlSection_d7beb3fd',
  button: 'button_d7beb3fd'
};

export default styles;
/* tslint:enable */