/* tslint:disable */
require("./Pagination.module.css");
const styles = {
  pagination: 'pagination_41bef2e7',
  rowsPerPage: 'rowsPerPage_41bef2e7',
  buttonStyle: 'buttonStyle_41bef2e7'
};

export default styles;
/* tslint:enable */