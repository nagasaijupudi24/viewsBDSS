/* tslint:disable */
require("./passcodePage.module.css");
const styles = {
  XenPasscode: 'XenPasscode_2c94db92',
  teams: 'teams_2c94db92',
  otp_input: 'otp_input_2c94db92',
  submitPasscode: 'submitPasscode_2c94db92',
  form_container: 'form_container_2c94db92',
  passcode_input: 'passcode_input_2c94db92',
  addPasscode: 'addPasscode_2c94db92',
  passcodebutton: 'passcodebutton_2c94db92',
  successDialog: 'successDialog_2c94db92',
  error: 'error_2c94db92',
  _createCard: '_createCard_2c94db92',
  timer: 'timer_2c94db92',
  resendPara: 'resendPara_2c94db92',
  confirmerror: 'confirmerror_2c94db92',
  eye_icon: 'eye_icon_2c94db92',
  eye_icon_view: 'eye_icon_view_2c94db92',
  eye_icon_view_confirm: 'eye_icon_view_confirm_2c94db92',
  otpverified: 'otpverified_2c94db92',
  passcodeHint: 'passcodeHint_2c94db92',
  selector: 'selector_2c94db92',
  tileDesign: 'tileDesign_2c94db92',
  passcode_btn_container: 'passcode_btn_container_2c94db92',
  passcode_header_conatiner: 'passcode_header_conatiner_2c94db92',
  otp_inputfield: 'otp_inputfield_2c94db92',
  card: 'card_2c94db92'
};

export default styles;
/* tslint:enable */