/* tslint:disable */
require("./Search.module.css");
const styles = {
  SearchWeb: 'SearchWeb_b128c178',
  teams: 'teams_b128c178',
  btn_Container: 'btn_Container_b128c178',
  customHeader: 'customHeader_b128c178',
  customFieldSet: 'customFieldSet_b128c178',
  _listviewContainerDataTable: '_listviewContainerDataTable_b128c178',
  commandbarContainer: 'commandbarContainer_b128c178',
  _totalDataCount: '_totalDataCount_b128c178'
};

export default styles;
/* tslint:enable */