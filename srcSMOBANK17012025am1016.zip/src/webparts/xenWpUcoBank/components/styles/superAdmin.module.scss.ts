/* tslint:disable */
require("./superAdmin.module.css");
const styles = {
  xenWpUcoBank: 'xenWpUcoBank_16f66420',
  teams: 'teams_16f66420',
  sectionheader: 'sectionheader_16f66420',
  customFieldSet: 'customFieldSet_16f66420',
  _dataTable: '_dataTable_16f66420',
  tableHeader_Containor: 'tableHeader_Containor_16f66420',
  peoplePicker_Containor: 'peoplePicker_Containor_16f66420',
  commandbarContainer: 'commandbarContainer_16f66420',
  commandbarContainerLeft: 'commandbarContainerLeft_16f66420',
  _listviewContainerDataTable: '_listviewContainerDataTable_16f66420',
  ChartViewcontainer: 'ChartViewcontainer_16f66420',
  ContorlSection: 'ContorlSection_16f66420',
  button: 'button_16f66420',
  landingPgTopBtnRow: 'landingPgTopBtnRow_16f66420',
  landingPgTopBtn: 'landingPgTopBtn_16f66420',
  inActivelandingPgTopBtn: 'inActivelandingPgTopBtn_16f66420',
  landingPgTopBtncontent: 'landingPgTopBtncontent_16f66420',
  _totalDataCount: '_totalDataCount_16f66420',
  mobile_homepage_btn: 'mobile_homepage_btn_16f66420'
};

export default styles;
/* tslint:enable */