/* tslint:disable */
require("./XenWpUcoBank.module.css");
const styles = {
  xenWpUcoBank: 'xenWpUcoBank_53be998d',
  teams: 'teams_53be998d',
  welcome: 'welcome_53be998d',
  welcomeImage: 'welcomeImage_53be998d',
  links: 'links_53be998d'
};

export default styles;
/* tslint:enable */